1. Running main file runs the program.
2. All modules are based on functions with proper documentation in comments.
3. Run the main program
4. Follow the prompts on the inputboxes to get output.
5. Once the program executes fully, and ends properly, the last polygon drawn is saved into the "output_file.txt"
6. The other text files can be utilized to create the patterns, but the transformations are necessary which are displayed in the video demo.

7. Details and outputs are given in the doc file